import React from 'react';
import {
  StyleSheet,
  SafeAreaView,
  View,
  Text,
  StatusBar,
  ScrollView,
  Image,
  Alert,
  TextInput,
} from 'react-native';

import FontAwesome from 'react-native-vector-icons/FontAwesome';

import SayHiComponent from '../component/SayHiComponent';
import IconHeaderComponent from '../component/IconHeaderComponent';

const HeaderComponent = () => {
  return (
    <View>
      <StatusBar translucent barStyle="dark-content" />

      <View style={styles.headerContainer}>
        <View style={styles.titleContainer}>
          <Text style={styles.txt_Title}>Cửa Hàng</Text>
          <IconHeaderComponent />
        </View>
        <View style={styles.searchContainer}>
          <TextInput style={styles.inputSearch} defaultValue="Tìm kiếm"
      />
          <IconHeaderComponent />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    paddingHorizontal: 16,
    paddingBottom: 16,
    borderBottomColor: '#efefef',
    borderBottomWidth: 1,
  },

  titleContainer: {
    flexDirection: 'row', // sắp xếp nội dung theo chiều ngan
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  searchContainer: {
    marginTop: 8,
    flexDirection: 'row', // sắp xếp nội dung theo chiều ngan
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  
  inputSearch:{
    flex:1,
    borderColor: 'gray',
    borderWidth: 1,
    padding: 16,
  },



  txt_Title: {
    fontSize: 18,
    fontWeight: '600',
  },
});

export default HeaderComponent;
