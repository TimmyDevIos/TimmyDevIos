export const dummyData =
        [{
                url: 'https://minio.thecoffeehouse.com/image/admin/CPG-COMBO-WEB-01.jpg_530519.png',
                id: 1

        },
        {
                url: 'https://minio.thecoffeehouse.com/image/admin/GANKET_web_734379.jpg',
                id: 2
        },
        {
                url: 'https://minio.thecoffeehouse.com/image/admin/CPG-COMBO-WEB-01.jpg_530519.png',
                id: 3

        },
        {
                url: 'https://minio.thecoffeehouse.com/image/admin/GANKET_web_734379.jpg',
                id: 4
        },
        ]