
const blog_1 = require('../assets/blogs/APP-NEWS-2.jpeg');
const blog_2 = require('../assets/blogs/New-TICHCUC2.jpeg');
const blog_3 = require('../assets/blogs/APPNEWS-3.jpeg');
const blog_4 = require('../assets/blogs/Appnews-4.jpeg');


export const dataBlog =
        [{
                img: blog_1,
                title:"Ưu đãi tháng 9 cho cà phê đúng gu",
                date: "02/09",
                id: 1
        },
        {
                img: blog_2,
                title:"Hi Tháng Mới, Nhà Mời 20% Nhé!",
                date: "02/09",
                id: 2
        },
        {
                img: blog_3,
                title:"Mừng Lễ Lớn, Nhà Mời 50%",
                date: "02/09",
                id: 3
        },
        {
                img: blog_4,
                title:"Giảm 35% Cho Đơn Từ 2 Món",
                date: "02/09",
                id: 4
        },
        {
                img: blog_1,
                title:"Ưu đãi tháng 9 cho cà phê đúng gu",
                date: "02/09",
                id: 5
        },
        {
                img: blog_2,
                title:"Hi Tháng Mới, Nhà Mời 20% Nhé!",
                date: "02/09",
                id: 6
        },
        {
                img: blog_3,
                title:"Mừng Lễ Lớn, Nhà Mời 50%",
                date: "02/09",
                id: 7
        },
        {
                img: blog_4,
                title:"Giảm 35% Cho Đơn Từ 2 Món",
                date: "02/09",
                id: 8
        },
        ]