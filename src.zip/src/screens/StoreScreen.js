import React from 'react';
import {StyleSheet, SafeAreaView , View, Text, StatusBar, ScrollView} from 'react-native';

import FontAwesome from 'react-native-vector-icons/FontAwesome';
import HeaderStoreComponent from '../component/HeaderStoreComponent';
import HomeBodyComponent from '../component/HomeBodyComponent';



const StoreScreen = () => {
  return (
    <SafeAreaView style={styles.screenContainer}>
      <HeaderStoreComponent />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: '#fefefe',
  },
});

export default StoreScreen;